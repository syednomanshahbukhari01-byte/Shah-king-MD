/**
 * SHAH KING BOT - Standalone Pair Code Generator
 * Generate pairing code without starting full bot
 */

const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  Browsers
} = require('@whiskeysockets/baileys');

const pino = require('pino');
const chalk = require('chalk');
const readline = require('readline');

async function askQuestion(query) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise(resolve => rl.question(query, ans => {
    rl.close();
    resolve(ans);
  }));
}

async function generatePairCode() {
  console.log(chalk.cyan.bold('\n╔════════════════════════════════════════╗'));
  console.log(chalk.cyan.bold('║     SHAH KING BOT - Pair Code          ║'));
  console.log(chalk.cyan.bold('╚════════════════════════════════════════╝\n'));

  const { state, saveCreds } = await useMultiFileAuthState('temp-session');
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    browser: Browsers.macOS('Desktop'),
    auth: state
  });

  console.log(chalk.yellow('Enter your WhatsApp number with country code:'));
  console.log(chalk.gray('Example: 923001234567'));
  console.log('');

  const phoneNumber = await askQuestion(chalk.green('Phone Number: '));

  if (!phoneNumber || phoneNumber.length < 10) {
    console.log(chalk.red('\n❌ Invalid phone number!'));
    process.exit(1);
  }

  console.log(chalk.yellow('\n⏳ Generating pairing code...\n'));

  try {
    const code = await sock.requestPairingCode(phoneNumber);
    
    console.log(chalk.green.bold('╔════════════════════════════════════════╗'));
    console.log(chalk.green.bold('║         YOUR PAIRING CODE              ║'));
    console.log(chalk.green.bold('╠════════════════════════════════════════╣'));
    console.log(chalk.green.bold(`║           ${code}            ║`));
    console.log(chalk.green.bold('╚════════════════════════════════════════╝\n'));
    
    console.log(chalk.cyan('📱 Instructions:'));
    console.log(chalk.white('1. Open WhatsApp on your phone'));
    console.log(chalk.white('2. Go to Settings → Linked Devices'));
    console.log(chalk.white('3. Tap "Link a Device"'));
    console.log(chalk.white('4. Enter the pairing code above\n'));

    console.log(chalk.yellow('⏳ Waiting for connection...\n'));

    sock.ev.on('connection.update', async (update) => {
      const { connection } = update;

      if (connection === 'open') {
        console.log(chalk.green.bold('✅ Connected successfully!\n'));
        console.log(chalk.cyan('Your session has been saved.'));
        console.log(chalk.cyan('You can now start the bot with: npm start\n'));
        
        // Copy session to main session folder
        const fs = require('fs-extra');
        await fs.copy('temp-session', 'shah-king-session');
        await fs.remove('temp-session');
        
        process.exit(0);
      }
    });

    sock.ev.on('creds.update', saveCreds);

  } catch (err) {
    console.log(chalk.red('\n❌ Error:'), err.message);
    process.exit(1);
  }
}

generatePairCode().catch(console.error);
