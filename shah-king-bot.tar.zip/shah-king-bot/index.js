/**
 * SHAH KING BOT - Ultimate WhatsApp Bot
 * Version: 5.0.0
 * Commands: 2000+
 * Features: Pair Code, Termux Ready, Baileys Based
 * Author: Shah King
 */

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeInMemoryStore,
  jidDecode,
  proto,
  getContentType,
  Browsers
} = require('@whiskeysockets/baileys');

const pino = require('pino');
const chalk = require('chalk');
const fs = require('fs-extra');
const path = require('path');
const readline = require('readline');
const { Boom } = require('@hapi/boom');
const { exec } = require('child_process');

// Import libraries
const { smsg } = require('./lib/myfunc');
const { color, bgColor } = require('./lib/color');
const { loadCommands } = require('./lib/commandLoader');
const { checkPremium } = require('./lib/premium');
const { getSettings, updateSettings } = require('./lib/settings');

// Global variables
global.owner = ['923000000000', '923111111111']; // Replace with your numbers
global.ownerName = 'Shah King';
global.botName = 'Shah King Bot';
global.version = '5.0.0';
global.prefix = '.';
global.sessionName = 'shah-king-session';
global.author = 'Shah King';
global.packname = 'Shah King Bot';
global.website = 'https://github.com/shahking';
global.done = '✅';
global.error = '❌';
global.wait = '⏳';
global.loading = '⌛';

// Database paths
const databasePath = './database';
if (!fs.existsSync(databasePath)) fs.mkdirSync(databasePath, { recursive: true });

// Store
const store = makeInMemoryStore({
  logger: pino().child({ level: 'silent', stream: 'store' })
});

// Command collection
global.commands = new Map();
global.aliases = new Map();
global.categories = [];

// Load all commands
console.log(chalk.blue.bold('╔════════════════════════════════════════╗'));
console.log(chalk.blue.bold('║     SHAH KING BOT - Loading...         ║'));
console.log(chalk.blue.bold('╚════════════════════════════════════════╝'));
console.log('');

const commandCount = loadCommands();
console.log(chalk.green(`✓ Loaded ${commandCount} commands successfully!`));
console.log(chalk.green(`✓ Categories: ${global.categories.join(', ')}`));
console.log('');

// Pairing code function
async function askQuestion(query) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise(resolve => rl.question(query, ans => {
    rl.close();
    resolve(ans);
  }));
}

// Main connection function
async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState(global.sessionName);
  const { version, isLatest } = await fetchLatestBaileysVersion();

  console.log(chalk.yellow(`Using Baileys version: ${version.join('.')}, isLatest: ${isLatest}`));
  console.log('');

  const sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false, // We'll use pairing code
    browser: Browsers.macOS('Desktop'),
    auth: state,
    getMessage: async (key) => {
      if (store) {
        const msg = await store.loadMessage(key.remoteJid, key.id);
        return msg?.message || undefined;
      }
      return proto.Message.fromObject({});
    }
  });

  store.bind(sock.ev);

  // Pairing code logic
  if (!sock.authState.creds.registered) {
    console.log(chalk.cyan.bold('╔════════════════════════════════════════╗'));
    console.log(chalk.cyan.bold('║     SHAH KING BOT - Pair Code          ║'));
    console.log(chalk.cyan.bold('╚════════════════════════════════════════╝'));
    console.log('');
    console.log(chalk.yellow('Enter your WhatsApp number with country code:'));
    console.log(chalk.gray('Example: 923001234567'));
    console.log('');

    const phoneNumber = await askQuestion(chalk.green('Phone Number: '));
    
    if (!phoneNumber || phoneNumber.length < 10) {
      console.log(chalk.red('❌ Invalid phone number!'));
      process.exit(1);
    }

    console.log(chalk.yellow('\nGenerating pairing code...'));
    
    try {
      const code = await sock.requestPairingCode(phoneNumber);
      console.log('');
      console.log(chalk.green.bold('╔════════════════════════════════════════╗'));
      console.log(chalk.green.bold('║         YOUR PAIRING CODE              ║'));
      console.log(chalk.green.bold('╠════════════════════════════════════════╣'));
      console.log(chalk.green.bold(`║     ${code}           ║`));
      console.log(chalk.green.bold('╚════════════════════════════════════════╝'));
      console.log('');
      console.log(chalk.cyan('Instructions:'));
      console.log(chalk.white('1. Open WhatsApp on your phone'));
      console.log(chalk.white('2. Go to Settings > Linked Devices'));
      console.log(chalk.white('3. Tap "Link a Device"'));
      console.log(chalk.white('4. Enter the pairing code above'));
      console.log('');
    } catch (err) {
      console.log(chalk.red('❌ Error generating pairing code:'), err.message);
      process.exit(1);
    }
  }

  // Connection update handler
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (connection === 'connecting') {
      console.log(chalk.yellow('⏳ Connecting to WhatsApp...'));
    }

    if (connection === 'open') {
      console.log(chalk.green.bold('\n╔════════════════════════════════════════╗'));
      console.log(chalk.green.bold('║     SHAH KING BOT CONNECTED!           ║'));
      console.log(chalk.green.bold('╠════════════════════════════════════════╣'));
      console.log(chalk.green.bold(`║  Bot Name: ${global.botName.padEnd(30)} ║`));
      console.log(chalk.green.bold(`║  Version: ${global.version.padEnd(31)} ║`));
      console.log(chalk.green.bold(`║  Commands: ${'2000+'.padEnd(31)} ║`));
      console.log(chalk.green.bold(`║  Owner: ${global.ownerName.padEnd(33)} ║`));
      console.log(chalk.green.bold('╚════════════════════════════════════════╝\n'));

      // Send connected message to owner
      for (let ownerNum of global.owner) {
        const ownerJid = ownerNum + '@s.whatsapp.net';
        await sock.sendMessage(ownerJid, {
          text: `*${global.botName} Connected!* ✅\n\n` +
                `*Version:* ${global.version}\n` +
                `*Commands:* 2000+\n` +
                `*Status:* Online\n` +
                `*Time:* ${new Date().toLocaleString()}\n\n` +
                `Type *${global.prefix}menu* to see all commands`
        });
      }
    }

    if (connection === 'close') {
      const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
      console.log(chalk.red(`Connection closed: ${reason}`));

      if (reason === DisconnectReason.badSession) {
        console.log(chalk.red('❌ Bad session, please delete session and scan again'));
        process.exit();
      } else if (reason === DisconnectReason.connectionClosed) {
        console.log(chalk.yellow('⚠️ Connection closed, reconnecting...'));
        startBot();
      } else if (reason === DisconnectReason.connectionLost) {
        console.log(chalk.yellow('⚠️ Connection lost, reconnecting...'));
        startBot();
      } else if (reason === DisconnectReason.connectionReplaced) {
        console.log(chalk.red('❌ Connection replaced, another session opened'));
        process.exit();
      } else if (reason === DisconnectReason.loggedOut) {
        console.log(chalk.red('❌ Device logged out, please scan again'));
        process.exit();
      } else if (reason === DisconnectReason.restartRequired) {
        console.log(chalk.yellow('🔄 Restart required, restarting...'));
        startBot();
      } else if (reason === DisconnectReason.timedOut) {
        console.log(chalk.yellow('⏱️ Connection timed out, reconnecting...'));
        startBot();
      } else {
        console.log(chalk.red(`Unknown reason: ${reason}`));
        startBot();
      }
    }
  });

  // Credentials update
  sock.ev.on('creds.update', saveCreds);

  // Messages handler
  sock.ev.on('messages.upsert', async (chatUpdate) => {
    try {
      const mek = chatUpdate.messages[0];
      if (!mek.message) return;

      mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage')
        ? mek.message.ephemeralMessage.message
        : (Object.keys(mek.message)[0] === 'viewOnceMessage')
          ? mek.message.viewOnceMessage.message
          : mek.message;

      if (!mek.key.fromMe && chatUpdate.type === 'notify') {
        console.log(chalk.green('[NEW MESSAGE]'), chalk.yellow(mek.key.remoteJid));
      }

      // Process message
      require('./handler')(sock, chatUpdate, store);
    } catch (err) {
      console.log(chalk.red('Error in messages.upsert:'), err);
    }
  });

  // Group participants update
  sock.ev.on('group-participants.update', async (update) => {
    try {
      const { id, participants, action } = update;
      const groupMetadata = await sock.groupMetadata(id);
      
      // Welcome/Goodbye messages
      if (action === 'add') {
        for (let participant of participants) {
          const user = participant.split('@')[0];
          const welcomeMsg = `👋 *Welcome to ${groupMetadata.subject}!*\n\n` +
                           `@${user}\n\n` +
                           `*Group Description:*\n${groupMetadata.desc || 'No description'}\n\n` +
                           `Type *${global.prefix}menu* to see available commands`;
          
          await sock.sendMessage(id, {
            text: welcomeMsg,
            mentions: [participant]
          });
        }
      } else if (action === 'remove') {
        for (let participant of participants) {
          const user = participant.split('@')[0];
          const goodbyeMsg = `👋 *Goodbye @${user}!*\n\n` +
                            `Thanks for being part of ${groupMetadata.subject}`;
          
          await sock.sendMessage(id, {
            text: goodbyeMsg,
            mentions: [participant]
          });
        }
      }
    } catch (err) {
      console.log(chalk.red('Error in group-participants.update:'), err);
    }
  });

  // Presence update
  sock.ev.on('presence.update', (update) => {
    // Handle presence updates if needed
  });

  // Delete message handler
  sock.ev.on('messages.delete', (item) => {
    // Handle deleted messages if needed
  });

  return sock;
}

// Start the bot
startBot().catch(err => {
  console.log(chalk.red('Error starting bot:'), err);
});

// Handle uncaught errors
process.on('uncaughtException', (err) => {
  console.log(chalk.red('Uncaught Exception:'), err);
});

process.on('unhandledRejection', (err) => {
  console.log(chalk.red('Unhandled Rejection:'), err);
});
