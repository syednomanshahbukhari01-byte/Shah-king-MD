module.exports = {
  name: 'mandub3',
  aliases: [],
  category: 'religion',
  description: 'Mandub checker',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MANDUB3*\n\nMandub checker\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
