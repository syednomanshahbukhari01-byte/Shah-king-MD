module.exports = {
  name: 'ayah',
  aliases: [],
  category: 'religion',
  description: 'Read Ayah',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*AYAH*\n\nRead Ayah\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
