module.exports = {
  name: 'tasbih',
  aliases: [],
  category: 'religion',
  description: 'Tasbih counter',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*TASBIH*\n\nTasbih counter\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
