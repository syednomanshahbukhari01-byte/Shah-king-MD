module.exports = {
  name: 'nafl3',
  aliases: [],
  category: 'religion',
  description: 'Nafl checker',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*NAFL3*\n\nNafl checker\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
