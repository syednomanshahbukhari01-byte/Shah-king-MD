module.exports = {
  name: 'fidya',
  aliases: [],
  category: 'religion',
  description: 'Fidya info',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*FIDYA*\n\nFidya info\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
