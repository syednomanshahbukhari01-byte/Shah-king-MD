module.exports = {
  name: 'sunnah',
  aliases: [],
  category: 'religion',
  description: 'Read Sunnah',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SUNNAH*\n\nRead Sunnah\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
