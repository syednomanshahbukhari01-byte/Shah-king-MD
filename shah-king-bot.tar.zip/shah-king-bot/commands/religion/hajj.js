module.exports = {
  name: 'hajj',
  aliases: [],
  category: 'religion',
  description: 'Hajj guide',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*HAJJ*\n\nHajj guide\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
