module.exports = {
  name: 'salah',
  aliases: [],
  category: 'religion',
  description: 'Prayer times',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SALAH*\n\nPrayer times\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
