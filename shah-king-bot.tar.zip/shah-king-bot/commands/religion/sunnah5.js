module.exports = {
  name: 'sunnah5',
  aliases: [],
  category: 'religion',
  description: 'Sunnah checker',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SUNNAH5*\n\nSunnah checker\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
