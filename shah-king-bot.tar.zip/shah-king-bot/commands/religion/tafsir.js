module.exports = {
  name: 'tafsir',
  aliases: [],
  category: 'religion',
  description: 'Quran tafsir',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*TAFSIR*\n\nQuran tafsir\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
