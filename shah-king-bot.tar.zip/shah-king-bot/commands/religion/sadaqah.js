module.exports = {
  name: 'sadaqah',
  aliases: [],
  category: 'religion',
  description: 'Sadaqah info',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SADAQAH*\n\nSadaqah info\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
