module.exports = {
  name: 'quran',
  aliases: [],
  category: 'religion',
  description: 'Read Quran',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*QURAN*\n\nRead Quran\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
