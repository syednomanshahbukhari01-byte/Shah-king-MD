module.exports = {
  name: 'wudu',
  aliases: [],
  category: 'religion',
  description: 'Wudu guide',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*WUDU*\n\nWudu guide\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
