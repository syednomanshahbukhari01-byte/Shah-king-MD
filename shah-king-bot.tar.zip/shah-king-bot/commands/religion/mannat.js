module.exports = {
  name: 'mannat',
  aliases: [],
  category: 'religion',
  description: 'Mannat info',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MANNAT*\n\nMannat info\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
