module.exports = {
  name: 'makruh',
  aliases: [],
  category: 'religion',
  description: 'Makruh checker',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MAKRUH*\n\nMakruh checker\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
