module.exports = {
  name: 'hijri',
  aliases: [],
  category: 'religion',
  description: 'Hijri date',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*HIJRI*\n\nHijri date\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
