module.exports = {
  name: 'eid',
  aliases: [],
  category: 'religion',
  description: 'Eid info',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*EID*\n\nEid info\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
