module.exports = {
  name: 'kaffarah',
  aliases: [],
  category: 'religion',
  description: 'Kaffarah info',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*KAFFARAH*\n\nKaffarah info\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
