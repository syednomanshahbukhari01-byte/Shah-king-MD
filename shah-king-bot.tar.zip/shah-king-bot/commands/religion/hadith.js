module.exports = {
  name: 'hadith',
  aliases: [],
  category: 'religion',
  description: 'Read Hadith',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*HADITH*\n\nRead Hadith\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
