module.exports = {
  name: 'layar',
  aliases: [],
  category: 'tools',
  description: 'Layar',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*LAYAR*\n\nLayar\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
