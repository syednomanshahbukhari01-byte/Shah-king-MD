module.exports = {
  name: 'vine',
  aliases: [],
  category: 'tools',
  description: 'Vine validation',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*VINE*\n\nVine validation\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
