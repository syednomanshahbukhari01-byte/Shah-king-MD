module.exports = {
  name: 'influxdb',
  aliases: [],
  category: 'tools',
  description: 'InfluxDB query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*INFLUXDB*\n\nInfluxDB query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
