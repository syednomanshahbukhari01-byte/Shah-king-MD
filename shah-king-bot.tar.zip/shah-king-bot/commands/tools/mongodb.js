module.exports = {
  name: 'mongodb',
  aliases: [],
  category: 'tools',
  description: 'MongoDB query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MONGODB*\n\nMongoDB query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
