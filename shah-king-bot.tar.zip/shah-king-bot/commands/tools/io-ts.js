module.exports = {
  name: 'io-ts',
  aliases: [],
  category: 'tools',
  description: 'io-ts validation',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*IO-TS*\n\nio-ts validation\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
