module.exports = {
  name: 'babylonjs',
  aliases: [],
  category: 'tools',
  description: 'Babylon.js',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*BABYLONJS*\n\nBabylon.js\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
