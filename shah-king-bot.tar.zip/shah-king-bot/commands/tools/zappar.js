module.exports = {
  name: 'zappar',
  aliases: [],
  category: 'tools',
  description: 'Zappar',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ZAPPAR*\n\nZappar\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
