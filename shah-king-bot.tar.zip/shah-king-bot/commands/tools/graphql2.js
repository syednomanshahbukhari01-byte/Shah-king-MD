module.exports = {
  name: 'graphql2',
  aliases: [],
  category: 'tools',
  description: 'GraphQL query 2',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*GRAPHQL2*\n\nGraphQL query 2\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
