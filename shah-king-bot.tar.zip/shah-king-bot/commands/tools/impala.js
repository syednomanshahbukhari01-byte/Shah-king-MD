module.exports = {
  name: 'impala',
  aliases: [],
  category: 'tools',
  description: 'Impala query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*IMPALA*\n\nImpala query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
