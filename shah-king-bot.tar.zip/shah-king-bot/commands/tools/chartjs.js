module.exports = {
  name: 'chartjs',
  aliases: [],
  category: 'tools',
  description: 'Chart.js style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*CHARTJS*\n\nChart.js style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
