module.exports = {
  name: 'fusion',
  aliases: [],
  category: 'tools',
  description: 'Fusion',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*FUSION*\n\nFusion\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
