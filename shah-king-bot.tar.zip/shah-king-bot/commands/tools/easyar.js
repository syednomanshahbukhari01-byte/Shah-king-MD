module.exports = {
  name: 'easyar',
  aliases: [],
  category: 'tools',
  description: 'EasyAR',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*EASYAR*\n\nEasyAR\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
