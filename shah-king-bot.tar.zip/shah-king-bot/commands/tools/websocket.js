module.exports = {
  name: 'websocket',
  aliases: [],
  category: 'tools',
  description: 'WebSocket tester',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*WEBSOCKET*\n\nWebSocket tester\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
