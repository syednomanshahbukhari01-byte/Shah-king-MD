module.exports = {
  name: 'idtech',
  aliases: [],
  category: 'tools',
  description: 'id Tech',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*IDTECH*\n\nid Tech\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
