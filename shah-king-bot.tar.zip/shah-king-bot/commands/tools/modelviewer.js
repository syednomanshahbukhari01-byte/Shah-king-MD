module.exports = {
  name: 'modelviewer',
  aliases: [],
  category: 'tools',
  description: 'Model Viewer',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MODELVIEWER*\n\nModel Viewer\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
