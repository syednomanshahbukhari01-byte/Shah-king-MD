module.exports = {
  name: 'vive',
  aliases: [],
  category: 'tools',
  description: 'Vive',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*VIVE*\n\nVive\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
