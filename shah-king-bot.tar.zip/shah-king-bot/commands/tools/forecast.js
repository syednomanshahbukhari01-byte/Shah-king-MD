module.exports = {
  name: 'forecast',
  aliases: [],
  category: 'tools',
  description: 'Weather forecast',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*FORECAST*\n\nWeather forecast\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
