module.exports = {
  name: 'apple',
  aliases: [],
  category: 'tools',
  description: 'Apple Vision Pro',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*APPLE*\n\nApple Vision Pro\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
