module.exports = {
  name: 'yaml',
  aliases: [],
  category: 'tools',
  description: 'YAML converter',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*YAML*\n\nYAML converter\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
