module.exports = {
  name: 'barcode',
  aliases: [],
  category: 'tools',
  description: 'Generate barcode',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*BARCODE*\n\nGenerate barcode\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
