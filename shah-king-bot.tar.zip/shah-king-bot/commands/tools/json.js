module.exports = {
  name: 'json',
  aliases: [],
  category: 'tools',
  description: 'JSON formatter',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*JSON*\n\nJSON formatter\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
