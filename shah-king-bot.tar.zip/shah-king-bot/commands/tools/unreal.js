module.exports = {
  name: 'unreal',
  aliases: [],
  category: 'tools',
  description: 'Unreal Engine',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*UNREAL*\n\nUnreal Engine\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
