module.exports = {
  name: 'base64',
  aliases: [],
  category: 'tools',
  description: 'Base64 encode/decode',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*BASE64*\n\nBase64 encode/decode\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
