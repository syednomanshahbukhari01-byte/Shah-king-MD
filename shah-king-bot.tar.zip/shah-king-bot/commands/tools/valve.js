module.exports = {
  name: 'valve',
  aliases: [],
  category: 'tools',
  description: 'Valve Index',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*VALVE*\n\nValve Index\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
