module.exports = {
  name: 'qr',
  aliases: [],
  category: 'tools',
  description: 'Generate QR',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*QR*\n\nGenerate QR\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
