module.exports = {
  name: 'csv',
  aliases: [],
  category: 'tools',
  description: 'CSV converter',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*CSV*\n\nCSV converter\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
