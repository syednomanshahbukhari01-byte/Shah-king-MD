module.exports = {
  name: 'graphql',
  aliases: [],
  category: 'tools',
  description: 'GraphQL query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*GRAPHQL*\n\nGraphQL query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
