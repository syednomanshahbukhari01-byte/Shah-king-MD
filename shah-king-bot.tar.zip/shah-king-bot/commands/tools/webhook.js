module.exports = {
  name: 'webhook',
  aliases: [],
  category: 'tools',
  description: 'Webhook tester',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*WEBHOOK*\n\nWebhook tester\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
