module.exports = {
  name: 'numeral',
  aliases: [],
  category: 'tools',
  description: 'Numeral.js',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*NUMERAL*\n\nNumeral.js\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
