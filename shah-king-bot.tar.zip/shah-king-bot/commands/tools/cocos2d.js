module.exports = {
  name: 'cocos2d',
  aliases: [],
  category: 'tools',
  description: 'Cocos2d',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*COCOS2D*\n\nCocos2d\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
