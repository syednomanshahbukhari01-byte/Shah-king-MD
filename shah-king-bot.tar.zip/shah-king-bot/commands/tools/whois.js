module.exports = {
  name: 'whois',
  aliases: [],
  category: 'tools',
  description: 'WHOIS lookup',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*WHOIS*\n\nWHOIS lookup\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
