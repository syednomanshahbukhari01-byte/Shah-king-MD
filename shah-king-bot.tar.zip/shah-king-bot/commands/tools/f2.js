module.exports = {
  name: 'f2',
  aliases: [],
  category: 'tools',
  description: 'F2 style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*F2*\n\nF2 style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
