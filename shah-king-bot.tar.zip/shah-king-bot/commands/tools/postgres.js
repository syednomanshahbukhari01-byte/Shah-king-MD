module.exports = {
  name: 'postgres',
  aliases: [],
  category: 'tools',
  description: 'PostgreSQL query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*POSTGRES*\n\nPostgreSQL query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
