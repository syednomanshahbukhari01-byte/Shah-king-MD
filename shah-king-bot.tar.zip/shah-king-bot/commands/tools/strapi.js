module.exports = {
  name: 'strapi',
  aliases: [],
  category: 'tools',
  description: 'Strapi query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*STRAPI*\n\nStrapi query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
