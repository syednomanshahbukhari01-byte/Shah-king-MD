module.exports = {
  name: 'phoenix',
  aliases: [],
  category: 'tools',
  description: 'Phoenix query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PHOENIX*\n\nPhoenix query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
