module.exports = {
  name: 'harlowe',
  aliases: [],
  category: 'tools',
  description: 'Harlowe',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*HARLOWE*\n\nHarlowe\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
