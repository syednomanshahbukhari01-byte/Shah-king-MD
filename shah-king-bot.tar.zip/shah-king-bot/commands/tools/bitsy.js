module.exports = {
  name: 'bitsy',
  aliases: [],
  category: 'tools',
  description: 'Bitsy',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*BITSY*\n\nBitsy\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
