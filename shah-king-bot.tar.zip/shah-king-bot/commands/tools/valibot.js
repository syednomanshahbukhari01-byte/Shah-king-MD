module.exports = {
  name: 'valibot',
  aliases: [],
  category: 'tools',
  description: 'Valibot validation',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*VALIBOT*\n\nValibot validation\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
