module.exports = {
  name: 'traceroute',
  aliases: [],
  category: 'tools',
  description: 'Traceroute',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*TRACEROUTE*\n\nTraceroute\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
