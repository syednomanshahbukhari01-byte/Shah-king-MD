module.exports = {
  name: 'maxst',
  aliases: [],
  category: 'tools',
  description: 'MAXST',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MAXST*\n\nMAXST\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
