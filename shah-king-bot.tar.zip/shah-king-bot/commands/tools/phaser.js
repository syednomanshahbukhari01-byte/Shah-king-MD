module.exports = {
  name: 'phaser',
  aliases: [],
  category: 'tools',
  description: 'Phaser',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PHASER*\n\nPhaser\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
