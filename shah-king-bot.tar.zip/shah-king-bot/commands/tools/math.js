module.exports = {
  name: 'math',
  aliases: [],
  category: 'tools',
  description: 'Math solver',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MATH*\n\nMath solver\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
