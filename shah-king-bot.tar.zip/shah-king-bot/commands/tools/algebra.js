module.exports = {
  name: 'algebra',
  aliases: [],
  category: 'tools',
  description: 'Algebra.js',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ALGEBRA*\n\nAlgebra.js\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
