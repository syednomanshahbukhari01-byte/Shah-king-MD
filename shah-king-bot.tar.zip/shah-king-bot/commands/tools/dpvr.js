module.exports = {
  name: 'dpvr',
  aliases: [],
  category: 'tools',
  description: 'DPVR',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*DPVR*\n\nDPVR\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
