module.exports = {
  name: 'arjs',
  aliases: [],
  category: 'tools',
  description: 'AR.js',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ARJS*\n\nAR.js\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
