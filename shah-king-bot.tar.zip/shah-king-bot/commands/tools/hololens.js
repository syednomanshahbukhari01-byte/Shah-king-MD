module.exports = {
  name: 'hololens',
  aliases: [],
  category: 'tools',
  description: 'HoloLens',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*HOLOLENS*\n\nHoloLens\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
