module.exports = {
  name: 'screenshot',
  aliases: [],
  category: 'tools',
  description: 'Web screenshot',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SCREENSHOT*\n\nWeb screenshot\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
