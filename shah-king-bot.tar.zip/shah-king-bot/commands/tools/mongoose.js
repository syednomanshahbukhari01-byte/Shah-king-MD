module.exports = {
  name: 'mongoose',
  aliases: [],
  category: 'tools',
  description: 'Mongoose query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MONGOOSE*\n\nMongoose query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
