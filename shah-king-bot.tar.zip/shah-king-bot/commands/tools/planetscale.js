module.exports = {
  name: 'planetscale',
  aliases: [],
  category: 'tools',
  description: 'PlanetScale query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PLANETSCALE*\n\nPlanetScale query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
