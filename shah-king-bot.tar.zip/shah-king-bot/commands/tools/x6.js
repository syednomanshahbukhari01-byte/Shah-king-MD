module.exports = {
  name: 'x6',
  aliases: [],
  category: 'tools',
  description: 'X6 style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*X6*\n\nX6 style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
