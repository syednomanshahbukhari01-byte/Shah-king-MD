module.exports = {
  name: 'openxr',
  aliases: [],
  category: 'tools',
  description: 'OpenXR',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*OPENXR*\n\nOpenXR\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
