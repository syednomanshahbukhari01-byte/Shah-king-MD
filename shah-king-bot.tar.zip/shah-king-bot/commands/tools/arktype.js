module.exports = {
  name: 'arktype',
  aliases: [],
  category: 'tools',
  description: 'ArkType validation',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ARKTYPE*\n\nArkType validation\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
