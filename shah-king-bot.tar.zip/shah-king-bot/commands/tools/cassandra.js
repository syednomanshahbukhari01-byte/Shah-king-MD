module.exports = {
  name: 'cassandra',
  aliases: [],
  category: 'tools',
  description: 'Cassandra query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*CASSANDRA*\n\nCassandra query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
