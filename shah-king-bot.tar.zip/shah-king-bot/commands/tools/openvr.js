module.exports = {
  name: 'openvr',
  aliases: [],
  category: 'tools',
  description: 'OpenVR',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*OPENVR*\n\nOpenVR\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
