module.exports = {
  name: 'unrealengine',
  aliases: [],
  category: 'tools',
  description: 'Unreal Engine',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*UNREALENGINE*\n\nUnreal Engine\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
