module.exports = {
  name: 'money',
  aliases: [],
  category: 'tools',
  description: 'Money.js',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MONEY*\n\nMoney.js\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
