module.exports = {
  name: 'artstation',
  aliases: [],
  category: 'tools',
  description: 'ArtStation',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ARTSTATION*\n\nArtStation\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
