module.exports = {
  name: 'varjo',
  aliases: [],
  category: 'tools',
  description: 'Varjo',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*VARJO*\n\nVarjo\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
