module.exports = {
  name: 'ndarray',
  aliases: [],
  category: 'tools',
  description: 'ndarray',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*NDARRAY*\n\nndarray\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
