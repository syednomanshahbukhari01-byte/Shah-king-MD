module.exports = {
  name: 'ms',
  aliases: [],
  category: 'tools',
  description: 'Millisecond parser',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MS*\n\nMillisecond parser\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
