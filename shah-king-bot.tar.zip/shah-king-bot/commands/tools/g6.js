module.exports = {
  name: 'g6',
  aliases: [],
  category: 'tools',
  description: 'G6 style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*G6*\n\nG6 style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
