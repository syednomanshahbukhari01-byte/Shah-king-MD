module.exports = {
  name: 'vx',
  aliases: [],
  category: 'tools',
  description: 'VX style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*VX*\n\nVX style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
