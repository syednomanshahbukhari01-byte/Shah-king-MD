module.exports = {
  name: 'banuba',
  aliases: [],
  category: 'tools',
  description: 'Banuba',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*BANUBA*\n\nBanuba\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
