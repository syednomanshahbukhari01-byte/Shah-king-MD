module.exports = {
  name: 'quest3',
  aliases: [],
  category: 'tools',
  description: 'Quest 3',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*QUEST3*\n\nQuest 3\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
