module.exports = {
  name: ' lumberyard',
  aliases: [],
  category: 'tools',
  description: 'Lumberyard',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`* LUMBERYARD*\n\nLumberyard\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
