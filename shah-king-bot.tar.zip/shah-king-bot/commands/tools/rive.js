module.exports = {
  name: 'rive',
  aliases: [],
  category: 'tools',
  description: 'Rive animation',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*RIVE*\n\nRive animation\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
