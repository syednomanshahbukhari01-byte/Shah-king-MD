module.exports = {
  name: 'ping',
  aliases: [],
  category: 'tools',
  description: 'Ping host',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PING*\n\nPing host\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
