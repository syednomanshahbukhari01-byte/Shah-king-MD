module.exports = {
  name: 'lottie',
  aliases: [],
  category: 'tools',
  description: 'Lottie animation',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*LOTTIE*\n\nLottie animation\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
