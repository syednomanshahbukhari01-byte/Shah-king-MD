module.exports = {
  name: 'beautify',
  aliases: [],
  category: 'tools',
  description: 'Beautify code',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*BEAUTIFY*\n\nBeautify code\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
