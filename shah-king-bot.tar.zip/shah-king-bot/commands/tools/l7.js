module.exports = {
  name: 'l7',
  aliases: [],
  category: 'tools',
  description: 'L7 style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*L7*\n\nL7 style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
