module.exports = {
  name: 'dns',
  aliases: [],
  category: 'tools',
  description: 'DNS lookup',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*DNS*\n\nDNS lookup\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
