module.exports = {
  name: 'effect',
  aliases: [],
  category: 'tools',
  description: 'Effect validation',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*EFFECT*\n\nEffect validation\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
