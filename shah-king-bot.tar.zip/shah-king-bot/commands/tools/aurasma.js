module.exports = {
  name: 'aurasma',
  aliases: [],
  category: 'tools',
  description: 'Aurasma',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*AURASMA*\n\nAurasma\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
