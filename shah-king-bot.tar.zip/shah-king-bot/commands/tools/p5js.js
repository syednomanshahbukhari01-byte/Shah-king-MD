module.exports = {
  name: 'p5js',
  aliases: [],
  category: 'tools',
  description: 'p5.js',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*P5JS*\n\np5.js\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
