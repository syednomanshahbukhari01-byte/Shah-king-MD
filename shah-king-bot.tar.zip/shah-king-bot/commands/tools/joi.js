module.exports = {
  name: 'joi',
  aliases: [],
  category: 'tools',
  description: 'Joi validation',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*JOI*\n\nJoi validation\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
