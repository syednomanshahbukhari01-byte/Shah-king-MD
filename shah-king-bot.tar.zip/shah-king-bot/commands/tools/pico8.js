module.exports = {
  name: 'pico8',
  aliases: [],
  category: 'tools',
  description: 'PICO-8',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PICO8*\n\nPICO-8\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
