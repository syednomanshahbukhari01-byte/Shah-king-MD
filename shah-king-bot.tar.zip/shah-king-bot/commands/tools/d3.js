module.exports = {
  name: 'd3',
  aliases: [],
  category: 'tools',
  description: 'D3.js style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*D3*\n\nD3.js style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
