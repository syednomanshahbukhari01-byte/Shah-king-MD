module.exports = {
  name: 'lenovo',
  aliases: [],
  category: 'tools',
  description: 'Lenovo Mirage',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*LENOVO*\n\nLenovo Mirage\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
