module.exports = {
  name: 'rsa',
  aliases: [],
  category: 'tools',
  description: 'RSA encryption',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*RSA*\n\nRSA encryption\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
