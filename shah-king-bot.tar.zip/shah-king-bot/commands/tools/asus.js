module.exports = {
  name: 'asus',
  aliases: [],
  category: 'tools',
  description: 'ASUS HC102',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ASUS*\n\nASUS HC102\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
