module.exports = {
  name: 'playcanvas2',
  aliases: [],
  category: 'tools',
  description: 'PlayCanvas 2',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PLAYCANVAS2*\n\nPlayCanvas 2\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
