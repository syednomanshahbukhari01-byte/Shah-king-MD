module.exports = {
  name: 'ocr',
  aliases: [],
  category: 'tools',
  description: 'Image to text',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*OCR*\n\nImage to text\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
