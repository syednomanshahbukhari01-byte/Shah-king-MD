module.exports = {
  name: 'hp',
  aliases: [],
  category: 'tools',
  description: 'HP Reverb',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*HP*\n\nHP Reverb\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
