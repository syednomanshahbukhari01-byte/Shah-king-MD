module.exports = {
  name: 'rifts',
  aliases: [],
  category: 'tools',
  description: 'Rift S',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*RIFTS*\n\nRift S\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
