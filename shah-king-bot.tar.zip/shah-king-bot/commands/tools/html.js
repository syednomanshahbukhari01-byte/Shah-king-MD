module.exports = {
  name: 'html',
  aliases: [],
  category: 'tools',
  description: 'HTML formatter',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*HTML*\n\nHTML formatter\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
