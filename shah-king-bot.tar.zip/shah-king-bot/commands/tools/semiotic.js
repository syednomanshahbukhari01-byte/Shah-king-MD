module.exports = {
  name: 'semiotic',
  aliases: [],
  category: 'tools',
  description: 'Semiotic style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SEMIOTIC*\n\nSemiotic style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
