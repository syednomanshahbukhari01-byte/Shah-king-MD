module.exports = {
  name: 'reactquery',
  aliases: [],
  category: 'tools',
  description: 'React Query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*REACTQUERY*\n\nReact Query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
