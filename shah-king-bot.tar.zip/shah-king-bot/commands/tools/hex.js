module.exports = {
  name: 'hex',
  aliases: [],
  category: 'tools',
  description: 'Hex encode/decode',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*HEX*\n\nHex encode/decode\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
