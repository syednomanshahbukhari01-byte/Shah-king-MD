module.exports = {
  name: 'arcore',
  aliases: [],
  category: 'tools',
  description: 'ARCore',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ARCORE*\n\nARCore\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
