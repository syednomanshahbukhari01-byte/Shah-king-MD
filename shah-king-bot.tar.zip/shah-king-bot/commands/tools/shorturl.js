module.exports = {
  name: 'shorturl',
  aliases: [],
  category: 'tools',
  description: 'Shorten URL',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SHORTURL*\n\nShorten URL\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
