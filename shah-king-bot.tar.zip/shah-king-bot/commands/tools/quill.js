module.exports = {
  name: 'quill',
  aliases: [],
  category: 'tools',
  description: 'Quill',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*QUILL*\n\nQuill\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
