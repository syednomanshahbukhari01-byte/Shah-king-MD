module.exports = {
  name: 'underscore',
  aliases: [],
  category: 'tools',
  description: 'Underscore utilities',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*UNDERSCORE*\n\nUnderscore utilities\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
