module.exports = {
  name: 'dell',
  aliases: [],
  category: 'tools',
  description: 'Dell Visor',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*DELL*\n\nDell Visor\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
