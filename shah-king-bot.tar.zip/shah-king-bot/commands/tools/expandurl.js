module.exports = {
  name: 'expandurl',
  aliases: [],
  category: 'tools',
  description: 'Expand URL',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*EXPANDURL*\n\nExpand URL\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
