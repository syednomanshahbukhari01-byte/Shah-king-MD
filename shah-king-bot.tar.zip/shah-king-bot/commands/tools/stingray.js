module.exports = {
  name: 'stingray',
  aliases: [],
  category: 'tools',
  description: 'Stingray',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*STINGRAY*\n\nStingray\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
