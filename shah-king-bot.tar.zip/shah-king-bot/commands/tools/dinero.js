module.exports = {
  name: 'dinero',
  aliases: [],
  category: 'tools',
  description: 'Dinero.js',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*DINERO*\n\nDinero.js\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
