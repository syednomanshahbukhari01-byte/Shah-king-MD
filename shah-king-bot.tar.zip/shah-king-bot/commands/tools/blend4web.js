module.exports = {
  name: 'blend4web',
  aliases: [],
  category: 'tools',
  description: 'Blend4Web',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*BLEND4WEB*\n\nBlend4Web\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
