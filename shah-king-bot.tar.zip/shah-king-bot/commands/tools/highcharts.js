module.exports = {
  name: 'highcharts',
  aliases: [],
  category: 'tools',
  description: 'Highcharts style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*HIGHCHARTS*\n\nHighcharts style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
