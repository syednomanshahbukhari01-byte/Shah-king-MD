module.exports = {
  name: 'qrscan',
  aliases: [],
  category: 'tools',
  description: 'Scan QR code',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*QRSCAN*\n\nScan QR code\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
