module.exports = {
  name: 'windowsmr',
  aliases: [],
  category: 'tools',
  description: 'Windows MR',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*WINDOWSMR*\n\nWindows MR\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
