module.exports = {
  name: 'prometheus',
  aliases: [],
  category: 'tools',
  description: 'Prometheus query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PROMETHEUS*\n\nPrometheus query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
