module.exports = {
  name: 'objection',
  aliases: [],
  category: 'tools',
  description: 'Objection query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*OBJECTION*\n\nObjection query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
