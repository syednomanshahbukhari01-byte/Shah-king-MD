module.exports = {
  name: 'react360',
  aliases: [],
  category: 'tools',
  description: 'React 360',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*REACT360*\n\nReact 360\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
