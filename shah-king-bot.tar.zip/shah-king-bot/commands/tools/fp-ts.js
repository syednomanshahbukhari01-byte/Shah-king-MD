module.exports = {
  name: 'fp-ts',
  aliases: [],
  category: 'tools',
  description: 'fp-ts',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*FP-TS*\n\nfp-ts\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
