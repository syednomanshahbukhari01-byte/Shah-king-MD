module.exports = {
  name: 'timestamp',
  aliases: [],
  category: 'tools',
  description: 'Unix timestamp',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*TIMESTAMP*\n\nUnix timestamp\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
