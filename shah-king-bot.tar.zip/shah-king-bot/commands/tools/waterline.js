module.exports = {
  name: 'waterline',
  aliases: [],
  category: 'tools',
  description: 'Waterline query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*WATERLINE*\n\nWaterline query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
