module.exports = {
  name: 'urql',
  aliases: [],
  category: 'tools',
  description: 'URQL query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*URQL*\n\nURQL query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
