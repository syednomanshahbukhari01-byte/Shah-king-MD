module.exports = {
  name: 'solr',
  aliases: [],
  category: 'tools',
  description: 'Solr query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SOLR*\n\nSolr query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
