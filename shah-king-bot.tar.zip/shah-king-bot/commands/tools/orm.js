module.exports = {
  name: 'orm',
  aliases: [],
  category: 'tools',
  description: 'ORM query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ORM*\n\nORM query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
