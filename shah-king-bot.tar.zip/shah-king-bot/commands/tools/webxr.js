module.exports = {
  name: 'webxr',
  aliases: [],
  category: 'tools',
  description: 'WebXR',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*WEBXR*\n\nWebXR\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
