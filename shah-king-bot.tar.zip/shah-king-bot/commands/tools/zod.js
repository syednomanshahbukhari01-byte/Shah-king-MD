module.exports = {
  name: 'zod',
  aliases: [],
  category: 'tools',
  description: 'Zod validation',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ZOD*\n\nZod validation\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
