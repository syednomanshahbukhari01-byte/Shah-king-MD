module.exports = {
  name: 'defold',
  aliases: [],
  category: 'tools',
  description: 'Defold',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*DEFOLD*\n\nDefold\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
