module.exports = {
  name: 'neo4j',
  aliases: [],
  category: 'tools',
  description: 'Neo4j query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*NEO4J*\n\nNeo4j query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
