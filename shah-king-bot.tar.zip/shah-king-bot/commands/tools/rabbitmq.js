module.exports = {
  name: 'rabbitmq',
  aliases: [],
  category: 'tools',
  description: 'RabbitMQ message',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*RABBITMQ*\n\nRabbitMQ message\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
