module.exports = {
  name: 'directus',
  aliases: [],
  category: 'tools',
  description: 'Directus query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*DIRECTUS*\n\nDirectus query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
