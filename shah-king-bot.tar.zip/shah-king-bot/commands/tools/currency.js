module.exports = {
  name: 'currency',
  aliases: [],
  category: 'tools',
  description: 'Currency converter',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*CURRENCY*\n\nCurrency converter\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
