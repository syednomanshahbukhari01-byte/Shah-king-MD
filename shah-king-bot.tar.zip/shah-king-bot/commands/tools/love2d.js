module.exports = {
  name: 'love2d',
  aliases: [],
  category: 'tools',
  description: 'LÖVE2D',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*LOVE2D*\n\nLÖVE2D\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
