module.exports = {
  name: 'decode',
  aliases: [],
  category: 'tools',
  description: 'Decode text',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*DECODE*\n\nDecode text\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
