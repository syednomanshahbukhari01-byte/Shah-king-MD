module.exports = {
  name: 'patch',
  aliases: [],
  category: 'tools',
  description: 'Apply patch',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PATCH*\n\nApply patch\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
