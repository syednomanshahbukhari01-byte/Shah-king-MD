module.exports = {
  name: 'renpy',
  aliases: [],
  category: 'tools',
  description: 'Ren'Py',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*RENPY*\n\nRen'Py\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
