module.exports = {
  name: 'presto',
  aliases: [],
  category: 'tools',
  description: 'Presto query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PRESTO*\n\nPresto query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
