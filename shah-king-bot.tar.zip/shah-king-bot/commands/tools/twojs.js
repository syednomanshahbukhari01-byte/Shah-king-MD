module.exports = {
  name: 'twojs',
  aliases: [],
  category: 'tools',
  description: 'Two.js',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*TWOJS*\n\nTwo.js\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
