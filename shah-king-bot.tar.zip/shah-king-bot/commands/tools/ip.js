module.exports = {
  name: 'ip',
  aliases: [],
  category: 'tools',
  description: 'IP lookup',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*IP*\n\nIP lookup\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
