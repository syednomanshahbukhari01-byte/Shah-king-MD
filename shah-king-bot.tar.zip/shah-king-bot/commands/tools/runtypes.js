module.exports = {
  name: 'runtypes',
  aliases: [],
  category: 'tools',
  description: 'Runtypes validation',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*RUNTYPES*\n\nRuntypes validation\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
