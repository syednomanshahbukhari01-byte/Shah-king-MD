module.exports = {
  name: 'api',
  aliases: [],
  category: 'tools',
  description: 'API tester',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*API*\n\nAPI tester\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
