module.exports = {
  name: 'soap',
  aliases: [],
  category: 'tools',
  description: 'SOAP request',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SOAP*\n\nSOAP request\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
