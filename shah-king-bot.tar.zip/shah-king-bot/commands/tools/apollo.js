module.exports = {
  name: 'apollo',
  aliases: [],
  category: 'tools',
  description: 'Apollo query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*APOLLO*\n\nApollo query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
