module.exports = {
  name: 'hash',
  aliases: [],
  category: 'tools',
  description: 'Generate hash',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*HASH*\n\nGenerate hash\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
