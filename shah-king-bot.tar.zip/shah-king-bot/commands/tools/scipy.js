module.exports = {
  name: 'scipy',
  aliases: [],
  category: 'tools',
  description: 'SciPy style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SCIPY*\n\nSciPy style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
