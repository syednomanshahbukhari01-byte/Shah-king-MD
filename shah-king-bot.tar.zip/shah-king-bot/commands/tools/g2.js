module.exports = {
  name: 'g2',
  aliases: [],
  category: 'tools',
  description: 'G2 style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*G2*\n\nG2 style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
