module.exports = {
  name: 'acer',
  aliases: [],
  category: 'tools',
  description: 'Acer OJO',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ACER*\n\nAcer OJO\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
