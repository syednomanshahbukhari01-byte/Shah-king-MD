module.exports = {
  name: 'canvas2d',
  aliases: [],
  category: 'tools',
  description: 'Canvas 2D',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*CANVAS2D*\n\nCanvas 2D\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
