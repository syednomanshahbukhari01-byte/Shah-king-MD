module.exports = {
  name: 'pgp',
  aliases: [],
  category: 'tools',
  description: 'PGP encryption',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PGP*\n\nPGP encryption\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
