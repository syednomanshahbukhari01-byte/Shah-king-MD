module.exports = {
  name: 'pimax',
  aliases: [],
  category: 'tools',
  description: 'Pimax',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PIMAX*\n\nPimax\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
