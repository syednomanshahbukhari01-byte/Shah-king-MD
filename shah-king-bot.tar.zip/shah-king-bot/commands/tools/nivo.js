module.exports = {
  name: 'nivo',
  aliases: [],
  category: 'tools',
  description: 'Nivo style',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*NIVO*\n\nNivo style\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
