module.exports = {
  name: 'construct3',
  aliases: [],
  category: 'tools',
  description: 'Construct 3',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*CONSTRUCT3*\n\nConstruct 3\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
