module.exports = {
  name: 'tic80',
  aliases: [],
  category: 'tools',
  description: 'TIC-80',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*TIC80*\n\nTIC-80\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
