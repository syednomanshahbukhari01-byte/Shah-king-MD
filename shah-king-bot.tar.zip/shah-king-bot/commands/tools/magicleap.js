module.exports = {
  name: 'magicleap',
  aliases: [],
  category: 'tools',
  description: 'Magic Leap',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MAGICLEAP*\n\nMagic Leap\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
