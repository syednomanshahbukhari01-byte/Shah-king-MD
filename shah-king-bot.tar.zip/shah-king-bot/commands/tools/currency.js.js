module.exports = {
  name: 'currency.js',
  aliases: [],
  category: 'tools',
  description: 'Currency.js',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*CURRENCY.JS*\n\nCurrency.js\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
