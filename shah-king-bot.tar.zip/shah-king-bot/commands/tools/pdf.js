module.exports = {
  name: 'pdf',
  aliases: [],
  category: 'tools',
  description: 'Web to PDF',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PDF*\n\nWeb to PDF\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
