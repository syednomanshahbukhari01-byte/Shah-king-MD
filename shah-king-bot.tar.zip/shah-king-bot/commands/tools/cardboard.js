module.exports = {
  name: 'cardboard',
  aliases: [],
  category: 'tools',
  description: 'Cardboard',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*CARDBOARD*\n\nCardboard\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
