module.exports = {
  name: 'questpro',
  aliases: [],
  category: 'tools',
  description: 'Quest Pro',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*QUESTPRO*\n\nQuest Pro\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
