module.exports = {
  name: 'stt',
  aliases: [],
  category: 'tools',
  description: 'Speech to text',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*STT*\n\nSpeech to text\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
