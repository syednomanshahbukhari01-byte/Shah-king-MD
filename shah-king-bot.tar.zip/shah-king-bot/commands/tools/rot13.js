module.exports = {
  name: 'rot13',
  aliases: [],
  category: 'tools',
  description: 'ROT13 cipher',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ROT13*\n\nROT13 cipher\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
