module.exports = {
  name: 'webgl',
  aliases: [],
  category: 'tools',
  description: 'WebGL',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*WEBGL*\n\nWebGL\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
