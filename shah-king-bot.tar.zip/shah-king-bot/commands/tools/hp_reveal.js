module.exports = {
  name: 'hp reveal',
  aliases: [],
  category: 'tools',
  description: 'HP Reveal',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*HP REVEAL*\n\nHP Reveal\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
