module.exports = {
  name: '8thwall',
  aliases: [],
  category: 'tools',
  description: '8th Wall',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*8THWALL*\n\n8th Wall\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
