module.exports = {
  name: 'sparkar',
  aliases: [],
  category: 'tools',
  description: 'Spark AR',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SPARKAR*\n\nSpark AR\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
