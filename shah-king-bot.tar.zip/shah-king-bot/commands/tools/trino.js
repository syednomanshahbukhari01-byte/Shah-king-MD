module.exports = {
  name: 'trino',
  aliases: [],
  category: 'tools',
  description: 'Trino query',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*TRINO*\n\nTrino query\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
