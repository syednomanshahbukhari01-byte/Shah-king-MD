module.exports = {
  name: 'docker',
  aliases: [],
  category: 'info',
  description: 'Docker image',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*DOCKER*\n\nDocker image\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
