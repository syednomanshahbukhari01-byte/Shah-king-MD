module.exports = {
  name: 'asus store',
  aliases: [],
  category: 'info',
  description: 'ASUS Store',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ASUS STORE*\n\nASUS Store\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
