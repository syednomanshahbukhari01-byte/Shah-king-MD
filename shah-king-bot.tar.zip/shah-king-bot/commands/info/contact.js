module.exports = {
  name: 'contact',
  aliases: [],
  category: 'info',
  description: 'Contact owner',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*CONTACT*\n\nContact owner\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
