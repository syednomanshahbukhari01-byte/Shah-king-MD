module.exports = {
  name: 'yum',
  aliases: [],
  category: 'info',
  description: 'YUM package',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*YUM*\n\nYUM package\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
