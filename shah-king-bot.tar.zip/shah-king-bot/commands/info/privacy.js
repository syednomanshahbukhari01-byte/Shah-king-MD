module.exports = {
  name: 'privacy',
  aliases: [],
  category: 'info',
  description: 'Privacy policy',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*PRIVACY*\n\nPrivacy policy\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
