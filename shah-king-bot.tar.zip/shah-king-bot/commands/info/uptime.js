module.exports = {
  name: 'uptime',
  aliases: [],
  category: 'info',
  description: 'Bot uptime',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*UPTIME*\n\nBot uptime\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
