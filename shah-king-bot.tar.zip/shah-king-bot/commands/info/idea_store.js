module.exports = {
  name: 'idea store',
  aliases: [],
  category: 'info',
  description: 'Idea Store',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*IDEA STORE*\n\nIdea Store\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
