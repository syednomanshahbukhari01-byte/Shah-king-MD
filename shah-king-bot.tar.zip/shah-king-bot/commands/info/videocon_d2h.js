module.exports = {
  name: 'videocon d2h',
  aliases: [],
  category: 'info',
  description: 'Videocon d2h',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*VIDEOCON D2H*\n\nVideocon d2h\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
