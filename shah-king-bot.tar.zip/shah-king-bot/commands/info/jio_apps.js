module.exports = {
  name: 'jio apps',
  aliases: [],
  category: 'info',
  description: 'JioApps',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*JIO APPS*\n\nJioApps\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
