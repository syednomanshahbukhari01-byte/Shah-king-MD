const { runtime } = require('../../lib/myfunc');
const fs = require('fs-extra');

module.exports = {
  name: 'runtime',
  aliases: ['uptime', 'status', 'botinfo'],
  category: 'info',
  description: 'Show bot runtime and statistics',
  props: {
    cooldown: 5
  },
  async execute({ sock, m }) {
    const uptime = runtime(process.uptime());
    const users = await fs.readJson('./database/users.json').catch(() => ({}));
    const groups = await fs.readJson('./database/groups.json').catch(() => ({}));
    const premium = await fs.readJson('./database/premium.json').catch(() => []);
    
    const totalUsers = Object.keys(users).length;
    const totalGroups = Object.keys(groups).length;
    const totalPremium = premium.length;
    const totalCommands = global.commands.size;

    const statusText = `*${global.botName} Status* ✅\n\n` +
      `*⏱️ Uptime:* ${uptime}\n` +
      `*👥 Users:* ${totalUsers}\n` +
      `*👥 Groups:* ${totalGroups}\n` +
      `*💎 Premium:* ${totalPremium}\n` +
      `*📚 Commands:* ${totalCommands}\n` +
      `*📊 Version:* ${global.version}\n` +
      `*👑 Owner:* ${global.ownerName}\n\n` +
      `_Bot is running smoothly!_`;

    m.reply(statusText);
  }
};
