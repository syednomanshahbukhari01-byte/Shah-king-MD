module.exports = {
  name: 'realme store',
  aliases: [],
  category: 'info',
  description: 'Realme Store',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*REALME STORE*\n\nRealme Store\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
