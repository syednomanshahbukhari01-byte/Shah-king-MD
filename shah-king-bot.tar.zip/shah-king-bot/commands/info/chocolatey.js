module.exports = {
  name: 'chocolatey',
  aliases: [],
  category: 'info',
  description: 'Chocolatey pkg',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*CHOCOLATEY*\n\nChocolatey pkg\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
