module.exports = {
  name: 'flatpak',
  aliases: [],
  category: 'info',
  description: 'Flatpak package',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*FLATPAK*\n\nFlatpak package\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
