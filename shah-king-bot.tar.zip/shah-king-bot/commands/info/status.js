module.exports = {
  name: 'status',
  aliases: [],
  category: 'info',
  description: 'Bot status',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*STATUS*\n\nBot status\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
