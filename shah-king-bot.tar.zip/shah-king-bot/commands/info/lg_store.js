module.exports = {
  name: 'lg store',
  aliases: [],
  category: 'info',
  description: 'LG Store',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*LG STORE*\n\nLG Store\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
