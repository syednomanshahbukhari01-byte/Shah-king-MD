module.exports = {
  name: 'reliance digital tv',
  aliases: [],
  category: 'info',
  description: 'Reliance Digital',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*RELIANCE DIGITAL TV*\n\nReliance Digital\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
