const { runtime } = require('../../lib/myfunc');
const os = require('os');

module.exports = {
  name: 'ping',
  aliases: ['speed', 'latency', 'pong'],
  category: 'info',
  description: 'Check bot response time',
  props: {
    cooldown: 5
  },
  async execute({ sock, m }) {
    const start = Date.now();
    const msg = await m.reply('🏓 Pinging...');
    const end = Date.now();
    
    const ping = end - start;
    const uptime = runtime(process.uptime());
    const memory = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
    const totalMem = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
    const freeMem = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);
    const cpu = os.cpus()[0].model;
    
    const pingText = `*🏓 PONG!*\n\n` +
      `*Response Time:* ${ping}ms\n` +
      `*Uptime:* ${uptime}\n` +
      `*Memory Usage:* ${memory} MB\n` +
      `*Total RAM:* ${totalMem} GB\n` +
      `*Free RAM:* ${freeMem} GB\n` +
      `*CPU:* ${cpu.split('@')[0].trim()}\n` +
      `*Platform:* ${os.platform()} ${os.arch()}\n` +
      `*Node.js:* ${process.version}`;

    await sock.sendMessage(m.chat, {
      edit: msg.key,
      text: pingText
    });
  }
};
