module.exports = {
  name: 'invite',
  aliases: [],
  category: 'info',
  description: 'Get invite',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*INVITE*\n\nGet invite\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
