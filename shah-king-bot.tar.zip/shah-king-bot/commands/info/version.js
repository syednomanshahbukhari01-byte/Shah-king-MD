module.exports = {
  name: 'version',
  aliases: [],
  category: 'info',
  description: 'Bot version',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*VERSION*\n\nBot version\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
