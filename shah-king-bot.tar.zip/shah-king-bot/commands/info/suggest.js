module.exports = {
  name: 'suggest',
  aliases: [],
  category: 'info',
  description: 'Suggest feature',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SUGGEST*\n\nSuggest feature\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
