module.exports = {
  name: 'nodeinfo',
  aliases: [],
  category: 'info',
  description: 'Node info',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*NODEINFO*\n\nNode info\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
