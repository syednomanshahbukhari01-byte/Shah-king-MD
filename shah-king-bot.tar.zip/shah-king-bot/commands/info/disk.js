module.exports = {
  name: 'disk',
  aliases: [],
  category: 'info',
  description: 'Disk usage',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*DISK*\n\nDisk usage\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
