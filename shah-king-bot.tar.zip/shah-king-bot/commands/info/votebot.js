module.exports = {
  name: 'votebot',
  aliases: [],
  category: 'info',
  description: 'Vote for bot',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*VOTEBOT*\n\nVote for bot\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
