module.exports = {
  name: 'arch',
  aliases: [],
  category: 'info',
  description: 'Architecture',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*ARCH*\n\nArchitecture\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
