module.exports = {
  name: 'galaxy store',
  aliases: [],
  category: 'info',
  description: 'Galaxy Store',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*GALAXY STORE*\n\nGalaxy Store\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
