module.exports = {
  name: 'motorola store',
  aliases: [],
  category: 'info',
  description: 'Motorola Store',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MOTOROLA STORE*\n\nMotorola Store\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
