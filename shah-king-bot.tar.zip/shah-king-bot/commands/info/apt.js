module.exports = {
  name: 'apt',
  aliases: [],
  category: 'info',
  description: 'APT package',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*APT*\n\nAPT package\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
