module.exports = {
  name: 'feedback',
  aliases: [],
  category: 'info',
  description: 'Send feedback',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*FEEDBACK*\n\nSend feedback\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
