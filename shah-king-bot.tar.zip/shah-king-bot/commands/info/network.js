module.exports = {
  name: 'network',
  aliases: [],
  category: 'info',
  description: 'Network info',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*NETWORK*\n\nNetwork info\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
