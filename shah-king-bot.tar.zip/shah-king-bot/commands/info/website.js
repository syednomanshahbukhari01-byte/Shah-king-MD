module.exports = {
  name: 'website',
  aliases: [],
  category: 'info',
  description: 'Get website',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*WEBSITE*\n\nGet website\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
