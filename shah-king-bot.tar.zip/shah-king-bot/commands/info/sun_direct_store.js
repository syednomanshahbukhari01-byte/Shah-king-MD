module.exports = {
  name: 'sun direct store',
  aliases: [],
  category: 'info',
  description: 'Sun Direct',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SUN DIRECT STORE*\n\nSun Direct\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
