module.exports = {
  name: 'menu',
  aliases: ['help', 'commands', 'cmd', 'start'],
  category: 'info',
  description: 'Show all available commands',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, args, prefix, pushname, isOwner, isPremium }) {
    const categories = {
      'owner': '👑 Owner',
      'group': '👥 Group',
      'download': '📥 Download',
      'fun': '😄 Fun',
      'sticker': '🎨 Sticker',
      'media': '🖼️ Media',
      'tools': '🛠️ Tools',
      'search': '🔍 Search',
      'game': '🎮 Game',
      'economy': '💰 Economy',
      'premium': '💎 Premium',
      'info': 'ℹ️ Info',
      'converter': '🔄 Converter',
      'ai': '🤖 AI',
      'religion': '🕌 Religion',
      'nsfw': '🔞 NSFW'
    };

    let menuText = `*${global.botName}* 🤖\n`;
    menuText += `Version: ${global.version}\n`;
    menuText += `Prefix: "${prefix}"\n\n`;
    menuText += `Hello *${pushname}*! 👋\n\n`;

    // If specific category requested
    if (args[0] && categories[args[0].toLowerCase()]) {
      const cat = args[0].toLowerCase();
      const commands = Array.from(global.commands.values())
        .filter(cmd => cmd.category === cat)
        .map(cmd => cmd.name)
        .sort();

      menuText += `*${categories[cat]} Commands*\n`;
      menuText += `Total: ${commands.length} commands\n\n`;
      
      let cmdText = '';
      for (let i = 0; i < commands.length; i++) {
        cmdText += `${prefix}${commands[i]}`;
        if ((i + 1) % 5 === 0) cmdText += '\n';
        else cmdText += ' | ';
      }
      menuText += cmdText.replace(/\| $/, '');
      
    } else {
      // Show all categories
      menuText += `*📋 Command Categories*\n\n`;
      
      for (const [key, value] of Object.entries(categories)) {
        const count = Array.from(global.commands.values())
          .filter(cmd => cmd.category === key).length;
        if (count > 0) {
          menuText += `${value}: ${count} cmds\n`;
          menuText += `└ ${prefix}menu ${key}\n`;
        }
      }

      menuText += `\n*📊 Total Commands:* ${global.commands.size}\n`;
      menuText += `*👤 Owner:* ${global.ownerName}\n\n`;
      
      menuText += `*💡 Tips:*\n`;
      menuText += `• ${prefix}help <command> for details\n`;
      menuText += `• ${prefix}menu <category> for category\n`;
      menuText += `• ${prefix}owner for owner info\n`;
    }

    menuText += `\n_Made with ❤️ by ${global.ownerName}_`;

    await sock.sendMessage(m.chat, {
      text: menuText,
      contextInfo: {
        externalAdReply: {
          title: global.botName,
          body: '2000+ Commands Available',
          thumbnailUrl: 'https://i.imgur.com/placeholder.png',
          sourceUrl: global.website
        }
      }
    }, { quoted: m });
  }
};
