module.exports = {
  name: 'group link',
  aliases: [],
  category: 'info',
  description: 'Get group link',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*GROUP LINK*\n\nGet group link\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
