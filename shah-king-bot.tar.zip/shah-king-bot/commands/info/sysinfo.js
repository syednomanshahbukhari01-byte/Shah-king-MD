module.exports = {
  name: 'sysinfo',
  aliases: [],
  category: 'info',
  description: 'System info',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*SYSINFO*\n\nSystem info\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
