module.exports = {
  name: 'fdroid',
  aliases: [],
  category: 'info',
  description: 'F-Droid',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*FDROID*\n\nF-Droid\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
