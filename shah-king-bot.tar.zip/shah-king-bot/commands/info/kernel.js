module.exports = {
  name: 'kernel',
  aliases: [],
  category: 'info',
  description: 'Kernel info',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*KERNEL*\n\nKernel info\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
