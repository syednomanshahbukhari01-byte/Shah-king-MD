module.exports = {
  name: 'aur',
  aliases: [],
  category: 'info',
  description: 'AUR package',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*AUR*\n\nAUR package\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
