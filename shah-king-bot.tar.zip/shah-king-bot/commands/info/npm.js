module.exports = {
  name: 'npm',
  aliases: [],
  category: 'info',
  description: 'NPM package',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*NPM*\n\nNPM package\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
