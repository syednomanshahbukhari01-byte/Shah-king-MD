module.exports = {
  name: 'copr',
  aliases: [],
  category: 'info',
  description: 'COPR repo',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*COPR*\n\nCOPR repo\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
