module.exports = {
  name: 'memory',
  aliases: [],
  category: 'info',
  description: 'Memory usage',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*MEMORY*\n\nMemory usage\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
