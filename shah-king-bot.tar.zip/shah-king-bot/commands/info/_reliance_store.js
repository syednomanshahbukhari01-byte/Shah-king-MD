module.exports = {
  name: ' reliance store',
  aliases: [],
  category: 'info',
  description: 'Reliance Store',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`* RELIANCE STORE*\n\nReliance Store\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
