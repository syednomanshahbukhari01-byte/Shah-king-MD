module.exports = {
  name: 'vivo appstore',
  aliases: [],
  category: 'info',
  description: 'Vivo Store',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*VIVO APPSTORE*\n\nVivo Store\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
