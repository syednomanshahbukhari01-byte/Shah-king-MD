module.exports = {
  name: 'obs',
  aliases: [],
  category: 'info',
  description: 'OBS repo',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*OBS*\n\nOBS repo\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
