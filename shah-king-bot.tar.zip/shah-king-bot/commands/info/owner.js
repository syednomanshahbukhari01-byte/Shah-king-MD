module.exports = {
  name: 'owner',
  aliases: ['creator', 'developer', 'dev'],
  category: 'info',
  description: 'Show owner information',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, prefix }) {
    const ownerText = `*👑 Owner Information*\n\n` +
      `*Name:* ${global.ownerName}\n` +
      `*Number:* ${global.owner[0]}\n` +
      `*Bot:* ${global.botName}\n` +
      `*Version:* ${global.version}\n\n` +
      `*📞 Contact:*\n` +
      `wa.me/${global.owner[0]}\n\n` +
      `*🌐 Website:*\n` +
      `${global.website}\n\n` +
      `_Type ${prefix}menu to see all commands_`;

    await sock.sendMessage(m.chat, {
      text: ownerText,
      contextInfo: {
        mentionedJid: global.owner.map(o => o + '@s.whatsapp.net'),
        externalAdReply: {
          title: global.ownerName,
          body: 'Bot Developer',
          sourceUrl: global.website
        }
      }
    }, { quoted: m });
  }
};
