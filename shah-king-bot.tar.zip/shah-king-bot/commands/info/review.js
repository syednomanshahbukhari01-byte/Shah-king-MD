module.exports = {
  name: 'review',
  aliases: [],
  category: 'info',
  description: 'Leave review',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*REVIEW*\n\nLeave review\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
