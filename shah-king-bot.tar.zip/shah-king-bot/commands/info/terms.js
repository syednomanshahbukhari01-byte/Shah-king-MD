module.exports = {
  name: 'terms',
  aliases: [],
  category: 'info',
  description: 'Terms of service',
  props: {
    cooldown: 5
  },
  async execute({ sock, m, q, args, text, prefix, command, sender, isGroup, isOwner, isPremium }) {
    m.reply(`*TERMS*\n\nTerms of service\n\n_This command is under development. Stay tuned for updates!_`);
  }
};
